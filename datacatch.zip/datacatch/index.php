<?php 
$host="localhost";
$user="root";
$password="";
$db="fctiws1314";
$dbcon=mysqli_connect("$host","$user","$password","$db");

if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];
    $day=$_POST['day'];
    $daydual=strlen($day)==1? "0".$day:$day;
    $month=$_POST['month'];
    $year=$_POST['year'];
    $dob=$year."-".$month."-".$daydual;
    $input_error=array();
    if(empty($name)){
       $input_error['name']="Name field is required";
    }
    if(empty($email)){
        $input_error['email']="Email field is required";
     }
     if(empty($mobile)){
        $input_error['mobile']="Mobile field is required";
     }
     if(empty($password)){
        $input_error['password']="Password field is required";
     }
     date_default_timezone_set("Asia/Dhaka");
     $join_date=date("Y-m-d");
     $password=md5($password);
  $query=mysqli_query($dbcon,"INSERT INTO `users`(`name`,`dob`, `email`, `mobile`, `password`, `join_date`) VALUES ('$name','$dob','$email','$mobile','$password','$join_date')");
     if($query){
       echo "
            <script>
                alert('Successfully inserted');
                window.location.href='index.php';
            </script>
       ";
        $name=false;
        $email=false;
        $mobile=false;
        $password=false;
       
     }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <label for="name">Name</label><br>
        <input type="text" name="name" id="name" value="<?php if(isset($name)){echo $name;}?>"><br>
        <small style="color:red;"><?php if(isset($input_error['name'])){echo $input_error['name'];}?></small><br>
        <label for="name">Date Of Birth</label><br>
       <select name="day">
            <?php 
            $day=1;
            while($day<=31){?>
            
                    <option value="<?=$day?>"><?=$day?></option>
<?php
           $day++;     
            }
            ?>
       </select>
       <select name="month">
           <option value="01">Jan</option>
           <option value="02">Feb</option>
           <option value="03">Mar</option>
           <option value="04">Apr</option>
           <option value="05">May</option>
           <option value="06">Jun</option>
           <option value="07">Jul</option>
           <option value="08">Aug</option>
           <option value="09">Sep</option>
           <option value="10">Oct</option>
           <option value="11">Nov</option>
           <option value="12">Dec</option>
       </select>
       <select name="year">
       <?php 
            $year=2024;
            while($year>=1905){?>
            
                    <option value="<?=$year?>"><?=$year?></option>
<?php
           $year--;     
            }
            ?>
       </select><br>
        <label for="email">Email</label><br>
        <input type="email" name="email" id="email" value="<?php if(isset($email)){echo $email;}?>"><br>
        <small style="color:red;"><?php if(isset($input_error['email'])){echo $input_error['email'];}?></small><br>
        <label for="mobile">Mobile</label><br>
        <input type="tel" name="mobile" id="mobile" value="<?php if(isset($mobile)){echo $mobile;}?>"><br>
        <small style="color:red;"><?php if(isset($input_error['mobile'])){echo $input_error['mobile'];}?></small><br>
        <label for="password">Password</label><br>
        <input type="password" name="password" id="password" value="<?php if(isset($password)){echo $password;}?>"><br>
        <small style="color:red;"><?php if(isset($input_error['password'])){echo $input_error['password'];}?></small><br>
        <input type="submit" value="Submit" name="submit">
    </form>
</body>
</html>